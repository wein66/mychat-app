export default {
    primary: '#f57c00',
    gray: '#c5c5c7',
    mediumGray: '#f6f7fb',
    lightGray: '#fafafa',
    bGround: '#cbebed'
}