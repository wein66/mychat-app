import React from 'react'
import { View, TouchableOpacity, Image, StyleSheet } from 'react-native';

const Login = () => {
  return (
    <View>
       <Text>Login</Text>
    </View>
  )
}

export default Login